﻿using ILGPU.Runtime;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structs
{
    public struct BVHNode
    {
        public Bounds3 Bounds { get; set; }
        public int Left { get; set; }
        public int Right { get; set; }
        public int Object { get; set; }
        public float Area { get; set; }

        // BVHBuildNode Public Methods
        public BVHNode()
        {
            Bounds = new();
            Left = -1;
            Right = -1;
            Object = -1;
            Area = 0;
        }
    }
}
